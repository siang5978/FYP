# ===========================
# File: CTFd/plugins/sqli/__init__.py
# Description:
# Plugin entry point for the SQL Injection challenge.
# Responsible for registering the challenge type,
# static assets, API routes, and startup cleanup logic.
# ===========================

from CTFd.plugins.challenges import CHALLENGE_CLASSES
from CTFd.plugins import register_plugin_assets_directory
from .sqli import SqliChallenge
from .router import sqli_bp
from .sqlilab.manager import cleanup_on_startup


# ===========================
# Plugin Loader
# ===========================
def load(app):
    # Ensure all database tables are created
    app.db.create_all()

    # Register the SQLi challenge type with CTFd
    CHALLENGE_CLASSES["sqli"] = SqliChallenge

    # Register the plugin's static assets directory
    register_plugin_assets_directory(
        app,
        base_path="/plugins/sqli/assets/"
    )

    # Register API routes for SQLi lab management
    app.register_blueprint(sqli_bp)

    # Perform cleanup tasks during plugin startup
    cleanup_on_startup()
