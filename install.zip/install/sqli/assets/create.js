// ===========================
// File: CTFd/plugins/sqli/assets/create.js
// Description:
// Admin-side logic for previewing the SQL Injection
// challenge description during creation.
// ===========================

CTFd.plugin.run((_CTFd) => {
  const $ = _CTFd.lib.$
  const md = _CTFd.lib.markdown()

  // ===========================
  // Markdown Preview Handler
  // ===========================
  $('a[href="#new-desc-preview"]').on('shown.bs.tab', function (event) {
    if (event.target.hash === '#new-desc-preview') {
      // Retrieve content from the description editor
      const editor_value = $('#new-desc-editor').val()

      // Render and display markdown preview
      $(event.target.hash).html(md.render(editor_value))
    }
  })
})
