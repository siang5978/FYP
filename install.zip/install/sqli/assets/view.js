// ===========================
// File: CTFd/plugins/sqli/assets/view.js
// Description:
// Client-side logic for rendering the SQLi challenge view,
// managing lab lifecycle actions, and updating UI state.
// ===========================


// ===========================
// Challenge Lifecycle Hooks
// ===========================
CTFd._internal.challenge.preRender = function () {
  // No pre-render logic required
}

CTFd._internal.challenge.render = function (markdown) {
  // Render challenge description using CTFd markdown renderer
  return CTFd.lib.markdown.render(markdown)
}

CTFd._internal.challenge.postRender = function () {

  // ===========================
  // Initial State Setup
  // ===========================
  if (CTFd._internal.challenge.sqliState === undefined) {
    CTFd._internal.challenge.sqliState = "stopped"
  }

  if (CTFd._internal.challenge.sqliUrl === undefined) {
    CTFd._internal.challenge.sqliUrl = null
  }

  // Update button visibility based on current state
  updateButtons()

  const $doc = CTFd.lib.$(document)

  // ===========================
  // Event Bindings
  // ===========================
  $doc.off("click", "#sqli-launch-btn")
  $doc.on("click", "#sqli-launch-btn", function () {
    launchLab()
  })

  $doc.off("click", "#sqli-stop-btn")
  $doc.on("click", "#sqli-stop-btn", function () {
    stopLab()
  })

  $doc.off("click", "#sqli-view-btn")
  $doc.on("click", "#sqli-view-btn", function () {
    viewLab()
  })

  // ===========================
  // Lab Level Resolver
  // ===========================
  // Determines lab difficulty based on challenge category
  function getLabLevel() {
    const challenge = CTFd._internal.challenge.data
    return (challenge && challenge.category || "").toLowerCase()
  }

  // ===========================
  // Launch Lab
  // ===========================
  function launchLab() {
    const level = getLabLevel()
    if (!level) {
      alert("Unknown SQLi lab category")
      return
    }

    fetch("/api/sqli/launch/" + level, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "CSRF-Token": CTFd.config.csrfNonce
      },
      credentials: "same-origin"
    })
      .then(res => res.json())
      .then(data => {
        if (!data.success) {
          alert("Failed to launch SQLi lab")
          return
        }

        // Store running lab state and access URL
        CTFd._internal.challenge.sqliUrl = data.url
        CTFd._internal.challenge.sqliState = "running"
        updateButtons()
      })
      .catch(() => {
        alert("Failed to launch SQLi lab")
      })
  }

  // ===========================
  // Stop Lab
  // ===========================
  function stopLab() {
    const level = getLabLevel()
    if (!level) return

    fetch("/api/sqli/stop/" + level, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "CSRF-Token": CTFd.config.csrfNonce
      },
      credentials: "same-origin"
    })
      .then(() => {
        // Reset lab state after successful stop
        CTFd._internal.challenge.sqliState = "stopped"
        CTFd._internal.challenge.sqliUrl = null
        updateButtons()
      })
      .catch(() => {
        alert("Failed to stop SQLi lab")
      })
  }

  // ===========================
  // View Lab
  // ===========================
  function viewLab() {
    const url = CTFd._internal.challenge.sqliUrl
    if (!url) {
      alert("SQLi lab is not running")
      return
    }

    // Open lab instance in a new browser tab
    window.open(url, "_blank")
  }

  // ===========================
  // UI State Management
  // ===========================
  function updateButtons() {
    const state = CTFd._internal.challenge.sqliState

    const $launch = CTFd.lib.$("#sqli-launch-btn")
    const $stop   = CTFd.lib.$("#sqli-stop-btn")
    const $view   = CTFd.lib.$("#sqli-view-btn")

    if (state === "stopped") {
      $launch.show()
      $stop.hide()
      $view.hide()
    }

    if (state === "running") {
      $launch.hide()
      $stop.show()
      $view.show()
    }
  }
}
