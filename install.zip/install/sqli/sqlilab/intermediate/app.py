# ===========================
# File: CTFd/plugins/sqli/sqlilab/intermediate/app.py
# Description:
# Intermediate-level SQL Injection lab application.
# This lab focuses on UNION-based SQL injection techniques
# to extract hidden data and flags.
# ===========================

from flask import Flask, request, render_template
import sqlite3
import sys
from pathlib import Path
from waitress import serve

# ===========================
# Flask Application Setup
# ===========================
app = Flask(__name__)

# ===========================
# Runtime Configuration
# ===========================
# Arguments passed from manager.py:
#   argv[1] -> SQLite database path
#   argv[2] -> Port number
#   argv[3] -> Host (optional)
DB_PATH = Path(sys.argv[1]).resolve()
PORT = int(sys.argv[2])
HOST = sys.argv[3] if len(sys.argv) > 3 else "127.0.0.1"

# Challenge flag revealed via successful SQL injection
FLAG = "Flag{Intermediate_SQLI_Success}"

# ===========================
# Database Helper
# ===========================
def get_db():
    """
    Create a SQLite connection to the lab database.
    Row factory is set to sqlite3.Row for iterable access.
    """
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


# ===========================
# Routes
# ===========================

# -------------------------------------------------
# Index Page
# -------------------------------------------------
@app.route("/", methods=["GET"])
def index():
    """
    Render the salary search interface.
    No results are shown on initial page load.
    """
    return render_template(
        "salary_search.html",
        results=None,
        error=None,
        found_flag=False
    )


# -------------------------------------------------
# Salary Search (Vulnerable Endpoint)
# -------------------------------------------------
@app.route("/search", methods=["GET"])
def salary_search():
    """
    Vulnerable search endpoint.
    The SQL query directly interpolates user input,
    enabling UNION-based SQL injection attacks.
    """
    user = request.args.get("user", "")
    results = []
    error = None
    found_flag = False

    if user:
        # ---------------------------
        # Intentionally vulnerable SQL
        # ---------------------------
        query = f"""
        SELECT username, month, salary
        FROM salaries
        WHERE username = '{user}'
        """

        try:
            conn = get_db()
            cur = conn.cursor()
            results = cur.execute(query).fetchall()

            # Scan query results for embedded flag values
            for row in results:
                for value in row:
                    if value and FLAG in str(value):
                        found_flag = True

        except Exception as e:
            # Surface SQL errors to assist exploitation
            error = str(e)

    return render_template(
        "salary_search.html",
        results=results,
        error=error,
        found_flag=found_flag
    )


# ===========================
# Application Entry Point
# ===========================
if __name__ == "__main__":
    # Use waitress for lightweight WSGI serving
    serve(
        app,
        host=HOST,
        port=PORT,
        threads=1
    )
