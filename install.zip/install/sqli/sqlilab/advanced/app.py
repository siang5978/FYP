# ===========================
# File: CTFd/plugins/sqli/sqlilab/advanced/app.py
# Description:
# Advanced-level SQL Injection lab application.
# This lab simulates a hardened login system with
# basic input filtering, requiring time-based or
# filter-bypass SQL injection techniques.
# ===========================

from flask import Flask, request, render_template, redirect, url_for
import sqlite3
import sys
from pathlib import Path
from waitress import serve
import time

# ===========================
# Flask Application Setup
# ===========================
app = Flask(__name__)

# ===========================
# Runtime Configuration
# ===========================
# Arguments passed from manager.py:
#   argv[1] -> SQLite database path
#   argv[2] -> Port number
#   argv[3] -> Host (optional)
DB_PATH = Path(sys.argv[1]).resolve()
PORT = int(sys.argv[2])
HOST = sys.argv[3] if len(sys.argv) > 3 else "127.0.0.1"


# ===========================
# Database Helper
# ===========================
def get_db():
    """
    Create a SQLite connection to the lab database.
    Registers a custom SQL sleep() function to
    enable time-based SQL injection attacks.
    """
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row

    # Register sleep(seconds) for time-based SQLi
    conn.create_function("sleep", 1, time.sleep)
    return conn


# ===========================
# Input Filter (Weak WAF)
# ===========================
def is_input_safe(user_input: str) -> bool:
    """
    Naive input filtering mechanism.
    Blocks common SQL keywords but can be bypassed.
    Designed to simulate imperfect real-world defenses.
    """
    lowered = user_input.lower()

    if " or " in lowered:
        return False
    if "union" in lowered:
        return False
    if "select" in lowered:
        return False
    if " like " in lowered:
        return False
    if " in " in lowered:
        return False

    return True


# ===========================
# Routes
# ===========================

# -------------------------------------------------
# Admin Audit Login (Vulnerable Endpoint)
# -------------------------------------------------
@app.route("/", methods=["GET", "POST"])
def audit_login():
    """
    Advanced SQLi challenge login endpoint.
    Uses weak keyword-based filtering and
    remains vulnerable to filter bypass and
    time-based SQL injection attacks.
    """
    msg = ""

    if request.method == "POST":
        username = request.form.get("username", "")
        password = request.form.get("password", "")

        # Apply naive input filtering to username only
        if not is_input_safe(username):
            return "Invalid username (blocked by security filter)."

        # ---------------------------
        # Intentionally vulnerable SQL
        # ---------------------------
        query = f"""
            SELECT * FROM admin_credentials
            WHERE username = '{username}' AND password = '{password}'
        """

        try:
            conn = get_db()
            cur = conn.cursor()
            result = cur.execute(query).fetchone()
        except Exception:
            result = None

        if result:
            # Successful exploitation redirects to success page
            return redirect(
                url_for(
                    "success",
                    flag=result["flag"]
                )
            )

        msg = "Invalid username or password."

    return render_template("audit_login.html", msg=msg)


# -------------------------------------------------
# Success Page
# -------------------------------------------------
@app.route("/success")
def success():
    """
    Display the extracted flag after successful SQL injection.
    """
    return render_template(
        "success.html",
        flag=request.args.get("flag")
    )


# ===========================
# Application Entry Point
# ===========================
if __name__ == "__main__":
    # Use waitress for isolated per-user lab execution
    serve(
        app,
        host=HOST,
        port=PORT,
        threads=1
    )
