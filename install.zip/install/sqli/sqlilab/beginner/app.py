# ===========================
# File: CTFd/plugins/sqli/sqlilab/beginner/app.py
# Description:
# Beginner-level SQL Injection lab application.
# This Flask app intentionally contains a SQL injection
# vulnerability for educational and challenge purposes.
# ===========================

from flask import Flask, request, render_template
import sqlite3
import sys
from pathlib import Path
from waitress import serve

# ===========================
# Flask Application Setup
# ===========================
app = Flask(__name__)

# ===========================
# Runtime Configuration
# ===========================
# Arguments passed from manager.py:
#   argv[1] -> SQLite database path
#   argv[2] -> Port number
#   argv[3] -> Host (optional)
DB_PATH = Path(sys.argv[1]).resolve()
PORT = int(sys.argv[2])
HOST = sys.argv[3] if len(sys.argv) > 3 else "127.0.0.1"

# Challenge flag returned upon successful exploitation
FLAG = "Flag{Beginner_SQLI_Success}"


# ===========================
# Database Helper
# ===========================
def get_db():
    """
    Create a SQLite connection to the lab database.
    Row factory is set to sqlite3.Row for dict-like access.
    """
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


# ===========================
# Routes
# ===========================
@app.route("/", methods=["GET", "POST"])
def login():
    """
    Vulnerable login endpoint.
    Uses string interpolation in SQL query,
    making it intentionally vulnerable to SQL injection.
    """
    msg = ""

    if request.method == "POST":
        username = request.form.get("username", "")
        password = request.form.get("password", "")

        # ---------------------------
        # Intentionally vulnerable SQL
        # ---------------------------
        query = (
            f"SELECT * FROM employees "
            f"WHERE username='{username}' AND password='{password}'"
        )

        try:
            conn = get_db()
            cur = conn.cursor()
            result = cur.execute(query).fetchone()
        except Exception as e:
            # Display SQL errors to assist learning
            msg = f"SQL Error: {e}"
            result = None

        if result:
            # Successful login (via SQLi or valid credentials)
            return render_template(
                "success.html",
                flag=FLAG,
                username=username,
                query=query
            )
        else:
            msg = "Invalid credentials"

    return render_template("login.html", msg=msg)


# ===========================
# Application Entry Point
# ===========================
if __name__ == "__main__":
    # Use waitress for production-like WSGI serving
    serve(
        app,
        host=HOST,
        port=PORT,
        threads=1
    )
