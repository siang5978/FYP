# ===========================
# File: CTFd/plugins/sqli/sqlilab/manager.py
# Description:
# Manages the lifecycle of SQL Injection lab instances.
# Responsible for port allocation, process management,
# temporary workspace handling, and cleanup operations.
# ===========================

from pathlib import Path
import sys
import subprocess
import json
import os
from .common.db_utils import init_db


# ===========================
# Paths Configuration
# ===========================
# Base directory of the sqlilab module
BASE_DIR = Path(__file__).parent

# Temporary directory for per-user lab data
TMP_DIR = BASE_DIR / "tmp"

# Mapping of lab difficulty levels to their directories
LAB_DIRS = {
    "beginner": BASE_DIR / "beginner",
    "intermediate": BASE_DIR / "intermediate",
    "advanced": BASE_DIR / "advanced",
}

# Ensure temporary directory exists
TMP_DIR.mkdir(parents=True, exist_ok=True)


# ===========================
# Port Management
# ===========================
# Base port range for exposing lab instances
BASE_PORT = 4001
MAX_PORT = 4002

# Track running labs and allocated ports
RUNNING_LABS = {}
USED_PORTS = set()


def allocate_port():
    # Allocate the first available port within the defined range
    for port in range(BASE_PORT, MAX_PORT):
        if port not in USED_PORTS:
            USED_PORTS.add(port)
            return port
    raise RuntimeError("No free ports available")


def release_port(port: int):
    # Release an allocated port
    USED_PORTS.discard(port)


# ===========================
# Lab Lifecycle Management
# ===========================
def start_lab(user_id: int, lab_type: str):
    # Validate lab difficulty type
    if lab_type not in LAB_DIRS:
        raise ValueError(f"Unknown lab type: {lab_type}")

    # Stop existing lab instance if already running
    if user_id in RUNNING_LABS and lab_type in RUNNING_LABS[user_id]:
        stop_lab(user_id, lab_type)

    # Create a temporary workspace for the user and lab type
    user_dir = TMP_DIR / f"user_{user_id}_{lab_type}"
    user_dir.mkdir(parents=True, exist_ok=True)

    # Initialize SQLite database for the lab
    db_path = user_dir / "db.sqlite"
    init_db(db_path, lab_type, insert_default=True)

    # Allocate a network port for the lab instance
    port = allocate_port()

    # Launch the lab process
    lab_dir = LAB_DIRS[lab_type]
    proc = subprocess.Popen(
        [
            sys.executable,
            "app.py",
            str(db_path),
            str(port),
            "0.0.0.0",
        ],
        cwd=lab_dir,
        creationflags=subprocess.CREATE_NEW_PROCESS_GROUP
    )

    # Store process metadata
    meta = {
        "pid": proc.pid,
        "port": port,
    }

    # Persist metadata to disk
    with open(user_dir / "meta.json", "w", encoding="utf-8") as f:
        json.dump(meta, f)

    # Register running lab in memory
    if user_id not in RUNNING_LABS:
        RUNNING_LABS[user_id] = {}
    RUNNING_LABS[user_id][lab_type] = meta

    return port


def stop_lab(user_id: int, lab_type: str):
    # Stop running lab instance tracked in memory
    if user_id in RUNNING_LABS and lab_type in RUNNING_LABS[user_id]:
        meta = RUNNING_LABS[user_id][lab_type]
        pid = meta.get("pid")
        port = meta.get("port")

        if pid:
            os.system(f"taskkill /PID {pid} /F")
        if port:
            release_port(port)

        del RUNNING_LABS[user_id][lab_type]
        if not RUNNING_LABS[user_id]:
            del RUNNING_LABS[user_id]

    # Fallback cleanup using persisted metadata
    user_dir = TMP_DIR / f"user_{user_id}_{lab_type}"
    meta_file = user_dir / "meta.json"

    if meta_file.exists():
        try:
            with open(meta_file, encoding="utf-8") as f:
                meta = json.load(f)
            pid = meta.get("pid")
            port = meta.get("port")
            if pid:
                os.system(f"taskkill /PID {pid} /F")
            if port:
                release_port(port)
        except Exception:
            pass

    # Remove temporary files and directory
    if user_dir.exists():
        for f in user_dir.iterdir():
            try:
                f.unlink()
            except Exception:
                pass
        try:
            user_dir.rmdir()
        except Exception:
            pass


# ===========================
# Cleanup on CTFd Startup
# ===========================
def cleanup_on_startup():
    # Reset in-memory tracking structures
    USED_PORTS.clear()
    RUNNING_LABS.clear()

    if not TMP_DIR.exists():
        return

    # Terminate any leftover lab processes and clean temp files
    for user_dir in TMP_DIR.iterdir():
        if not user_dir.is_dir():
            continue

        meta_file = user_dir / "meta.json"
        if meta_file.exists():
            try:
                with open(meta_file, encoding="utf-8") as f:
                    meta = json.load(f)
                pid = meta.get("pid")
                if pid:
                    os.system(f"taskkill /PID {pid} /F")
            except Exception:
                pass

        try:
            for f in user_dir.iterdir():
                f.unlink()
            user_dir.rmdir()
        except Exception:
            pass
