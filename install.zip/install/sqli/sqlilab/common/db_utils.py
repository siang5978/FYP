# ===========================
# File: CTFd/plugins/sqli/sqlilab/common/db_utils.py
# Description:
# Utility module for initializing SQLite databases for SQLi labs.
# Provides table schemas, default data, and helper functions
# to prepare per-user lab databases.
# ===========================

from pathlib import Path
import sqlite3


# ===========================
# SQL Table Definitions
# ===========================
# Each lab type has its own table schemas
TABLE_SCHEMAS = {
    "beginner": [
        """
        CREATE TABLE IF NOT EXISTS employees (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT,
            password TEXT,
            gender TEXT
        )
        """
    ],
    "intermediate": [
        """
        CREATE TABLE IF NOT EXISTS employees (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT,
            password TEXT,
            gender TEXT
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS salaries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT,
            month TEXT,
            salary INTEGER
        )
        """
    ],
    "advanced": [
        """
        CREATE TABLE IF NOT EXISTS admin_credentials (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT,
            password TEXT,
            flag TEXT
        )
        """
    ]
}


# ===========================
# Default Data to Insert
# ===========================
# Populates tables with default rows for each lab type
DEFAULT_DATA = {
    "beginner": [
        ("employees", ["username", "password", "gender"], [
            ("john", "johnpass", "M"),
            ("alice", "alicepass", "F"),
            ("bob", "bobpass", "M")
        ])
    ],
    "intermediate": [
        ("employees", ["username", "password", "gender"], [
            ("john", "johnpass", "M"),
            ("alice", "alicepass", "F"),
            ("bob", "Flag{Intermediate_SQLI_Success}", "M")
        ]),
        ("salaries", ["username", "month", "salary"], [
            ("alice", "2025-10", 4500),
            ("alice", "2025-11", 4200),
            ("bob", "2025-10", 5200),
            ("bob", "2025-11", 5300),
            ("bob", "2025-12", 5100),
            ("john", "2025-10", 5660),
            ("john", "2025-11", 5200)
        ])
    ],
    "advanced": [
        ("admin_credentials", ["username", "password", "flag"], [
            ("admin", "SuperSecurePassword", "Flag{Advanced_SQLI_Success}"),
            ("audit1", "pwdaudit", None),
            ("audit2", "pwdaudit", None)
        ])
    ]
}


# ===========================
# Database Initialization Utility
# ===========================
def init_db(db_path: Path, lab_type: str, insert_default: bool = True):
    """
    Initialize a SQLite database for a given lab type.

    Args:
        db_path (Path): Path to the SQLite database file.
        lab_type (str): Lab difficulty type ('beginner', 'intermediate', 'advanced').
        insert_default (bool): Whether to populate tables with default data.

    Raises:
        ValueError: If an unknown lab_type is provided.
    """
    if lab_type not in TABLE_SCHEMAS:
        raise ValueError(f"Unknown lab type: {lab_type}")

    # Connect to SQLite database
    conn = sqlite3.connect(db_path)
    c = conn.cursor()

    # Create all tables for this lab type
    for sql in TABLE_SCHEMAS[lab_type]:
        c.execute(sql)

    # Insert default data if requested
    if insert_default:
        for table_name, columns, rows in DEFAULT_DATA.get(lab_type, []):
            placeholders = ", ".join("?" for _ in columns)
            col_names = ", ".join(columns)
            c.executemany(
                f"INSERT INTO {table_name} ({col_names}) VALUES ({placeholders})",
                rows
            )

    # Commit changes and close connection
    conn.commit()
    conn.close()
