# ===========================
# File: CTFd/plugins/sqli/sqli.py
# Description:
# Defines the custom SQL Injection challenge model
# and challenge type for the CTFd platform.
# ===========================

from CTFd.models import db, Challenges, Flags
from CTFd.plugins.challenges import BaseChallenge
from CTFd.utils.user import get_current_user, get_current_team


# ===========================
# 1. SQLi Challenge Model
# ===========================
class SqliChallengeModel(Challenges):
    __mapper_args__ = {"polymorphic_identity": "sqli"}

    # Primary key inherited from the base Challenges table
    id = db.Column(None, db.ForeignKey("challenges.id"), primary_key=True)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)


# ===========================
# 2. SQLi Challenge Type
# ===========================
class SqliChallenge(BaseChallenge):
    # Unique identifier for this challenge type
    id = "sqli"

    # Display name shown in the CTFd admin panel
    name = "SQL Injection"

    # Database model associated with this challenge type
    challenge_model = SqliChallengeModel

    # ===========================
    # Templates
    # ===========================
    templates = {
        "create": "/plugins/sqli/assets/create.html",
        "update": "/plugins/sqli/assets/update.html",
        "view": "/plugins/sqli/assets/view.html",
    }

    # ===========================
    # Scripts
    # ===========================
    scripts = {
        "create": "/plugins/sqli/assets/create.js",
        "update": "/plugins/sqli/assets/update.js",
        "view": "/plugins/sqli/assets/view.js",
    }

    # ===========================
    # CREATE
    # ===========================
    @classmethod
    def create(cls, request):
        # Retrieve challenge data from form or JSON request
        data = request.form or request.get_json() or {}

        # Create a new SQLi challenge instance
        challenge = cls.challenge_model(**data)

        # Persist the challenge to the database
        db.session.add(challenge)
        db.session.commit()

        return challenge

    # ===========================
    # READ
    # ===========================
    @classmethod
    def read(cls, challenge):
        # Serialize challenge data for API responses
        return {
            "id": challenge.id,
            "name": challenge.name,
            "description": challenge.description,
            "value": challenge.value,
            "category": challenge.category,
            "state": challenge.state,
            "max_attempts": challenge.max_attempts,
            "type": challenge.type,
            "type_data": {
                "id": cls.id,
                "name": cls.name,
                "templates": cls.templates,
                "scripts": cls.scripts,
            },
        }
