# ===========================
# File: CTFd/plugins/sqli/router.py
# Description:
# Defines API routes for launching and stopping
# SQL Injection lab instances for authenticated users.
# ===========================

from flask import Blueprint, jsonify, request
from CTFd.utils.decorators import authed_only
from CTFd.utils.user import get_current_user

from .sqlilab.manager import start_lab, stop_lab


# ===========================
# Blueprint Definition
# ===========================
# Blueprint for SQLi plugin API routes
sqli_bp = Blueprint("sqli", __name__)


# ===========================
# Launch Lab Endpoint
# ===========================
@sqli_bp.route("/api/sqli/launch/<level>", methods=["POST"])
@authed_only  # User must be authenticated
def launch_sqli_lab(level):
    # Normalize the difficulty level
    level = level.lower()

    # Retrieve the currently logged-in user
    user = get_current_user()

    try:
        # Start a new SQLi lab instance and obtain the exposed port
        port = start_lab(user.id, level)
    except ValueError:
        # Invalid lab level provided
        return jsonify({"success": False, "msg": "Invalid level"}), 400
    except Exception as e:
        # Unexpected error during lab startup
        return jsonify({"success": False, "msg": str(e)}), 500

    # Build the access URL for the lab instance
    host = request.host.split(":")[0]
    url = f"http://{host}:{port}"

    # Return lab connection details
    return jsonify({
        "success": True,
        "level": level,
        "user_id": user.id,
        "port": port,
        "url": url
    })


# ===========================
# Stop Lab Endpoint
# ===========================
@sqli_bp.route("/api/sqli/stop/<level>", methods=["POST"])
@authed_only  # User must be authenticated
def stop_sqli_lab(level):
    # Normalize the difficulty level
    level = level.lower()

    # Retrieve the currently logged-in user
    user = get_current_user()

    try:
        # Stop the running SQLi lab instance
        stop_lab(user.id, level)
    except ValueError:
        # Invalid lab level provided
        return jsonify({"success": False, "msg": "Invalid level"}), 400
    except Exception as e:
        # Unexpected error during lab shutdown
        return jsonify({"success": False, "msg": str(e)}), 500

    # Confirm successful lab shutdown
    return jsonify({
        "success": True,
        "level": level,
        "user_id": user.id
    })
