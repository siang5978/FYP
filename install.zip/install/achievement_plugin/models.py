# ===========================
# File: CTFd/plugins/achievement_plugin/models.py
# Description:
# Defines the database models for the Achievement plugin.
# - Achievement: stores achievement metadata like name,
#   description, and visibility.
# - AchievementChallenge: defines the relationship between
#   achievements and dependent challenges.
# Achievements are dynamically evaluated for users based on
# their solved challenges.
# ===========================

from CTFd.models import db
from datetime import datetime

# ==========================
# Session 1: Achievement Model
# ==========================
class Achievement(db.Model):
    """
    Represents an achievement in CTFd.
    Admins can define a name, description, and visibility.
    """
    __tablename__ = "achievements"

    id = db.Column(db.Integer, primary_key=True)  # Unique achievement ID
    name = db.Column(db.String(80))               # Achievement title
    description = db.Column(db.String(255))       # Brief description
    visible = db.Column(db.String(10), default="Hidden")  # Visibility: Hidden or Visible

# ==========================
# Session 2: Achievement-Challenge Relationship
# ==========================
class AchievementChallenge(db.Model):
    """
    Maps achievements to challenges.
    An achievement can depend on one or more challenges.
    """
    __tablename__ = "achievement_challenges"

    id = db.Column(db.Integer, primary_key=True)                       # Unique ID for this mapping
    achievement_id = db.Column(db.Integer, db.ForeignKey('achievements.id'))  # Related achievement
    challenge_id = db.Column(db.Integer, db.ForeignKey('challenges.id'))      # Related challenge
